class Usuario {
  String? nome;

  Usuario(this.nome);
}

void main() {
  Usuario? user = Usuario("Carlos");

  print(user?.nome ?? "Usuário não definido");
}
class ItemBiblioteca {
  String titulo;
  int ano;

  ItemBiblioteca(this.titulo, this.ano);

  void exibirInfo() {
    print("Título: $titulo | Ano: $ano");
  }
}

class Livro extends ItemBiblioteca {
  String autor;

  Livro(String titulo, int ano, this.autor) : super(titulo, ano);

  @override
  void exibirInfo() {
    print("Livro: $titulo | Autor: $autor | Ano: $ano");
  }
}

class Revista extends ItemBiblioteca {
  int edicao;

  Revista(String titulo, int ano, this.edicao) : super(titulo, ano);

  @override
  void exibirInfo() {
    print("Revista: $titulo | Edição: $edicao | Ano: $ano");
  }
}

void main() {
  Livro livro = Livro("Clean Code", 2008, "Robert Martin");
  Revista revista = Revista("Tech Monthly", 2024, 10);

  livro.exibirInfo();
  revista.exibirInfo();
}
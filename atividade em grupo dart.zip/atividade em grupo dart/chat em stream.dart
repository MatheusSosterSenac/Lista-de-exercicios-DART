import 'dart:async';

class Chat {
  final StreamController<String> _controller = StreamController();

  Stream<String> get mensagens => _controller.stream;

  void enviarMensagem(String msg) {
    _controller.sink.add(msg);
  }

  void fechar() {
    _controller.close();
  }
}

void main() {
  Chat chat = Chat();

  chat.mensagens.listen((msg) {
    print("Nova mensagem: $msg");
  });

  chat.enviarMensagem("Olá!");
  chat.enviarMensagem("Como vai?");
}
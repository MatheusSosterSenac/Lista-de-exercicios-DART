import 'dart:async';

Future<String> buscarClima(String cidade) async {
  await Future.delayed(Duration(seconds: 2));

  if (cidade.isEmpty) {
    throw Exception("Cidade inválida");
  }

  return "Clima em $cidade: 25°C e ensolarado";
}

void main() async {
  try {
    String clima = await buscarClima("Joinville");
    print(clima);
  } catch (e) {
    print("Erro ao buscar clima: $e");
  }
}
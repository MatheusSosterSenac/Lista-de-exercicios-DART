import 'package:flutter/material.dart';
import 'dashboard_card.dart';
import 'simple_chart.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dashboard Responsivo Animado',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      home: const MyHomePage(title: 'Dashboard'),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;

    // Lista de cards
    List<Widget> cards = [
      DashboardCard(
        title: "Vendas",
        value: "R\$ 10k",
        icon: Icons.attach_money,
        color: Colors.green,
      ),
      DashboardCard(
        title: "Clientes",
        value: "200",
        icon: Icons.people,
        color: Colors.blue,
      ),
      DashboardCard(
        title: "Pedidos",
        value: "150",
        icon: Icons.shopping_cart,
        color: Colors.orange,
      ),
      DashboardCard(
        title: "Lucro",
        value: "R\$ 5k",
        icon: Icons.show_chart,
        color: Colors.purple,
      ),
    ];

    // Widget gráfico simples
    Widget chart = Padding(
      padding: const EdgeInsets.symmetric(vertical: 20),
      child: Column(
        children: const [
          Text('Gráfico de Progresso', style: TextStyle(fontSize: 16)),
          SizedBox(height: 10),
          SimpleChart(progress: 0.7),
        ],
      ),
    );

    Widget layout;
    Key layoutKey;

    if (width < 600) {
      layoutKey = const ValueKey('mobile');
      layout = Column(
        children: [
          ...cards.map((card) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: card,
            );
          }).toList(),
          chart,
        ],
      );
    } else if (width < 900) {
      layoutKey = const ValueKey('tablet');
      layout = Wrap(
        spacing: 10,
        runSpacing: 10,
        children: [
          ...cards.map((card) {
            return SizedBox(
              width: width / 2 - 20,
              child: card,
            );
          }).toList(),
          SizedBox(
            width: width / 2 - 20,
            child: chart,
          ),
        ],
      );
    } else {
      layoutKey = const ValueKey('desktop');
      layout = Row(
        children: [
          ...cards.map((card) {
            return Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: card,
              ),
            );
          }).toList(),
          Expanded(child: chart),
        ],
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          child: Container(
            key: layoutKey,
            child: layout,
          ),
          switchInCurve: Curves.easeIn,
          switchOutCurve: Curves.easeOut,
        ),
      ),
    );
  }
}